import pygame
import random

pygame.init()

# resolution of screen
width = 1000
height = 500

screen = pygame.display.set_mode((width, height))
# color = (r,g,b) - 0 to 255
red = (255, 0, 0)
blue = (0, 0, 255)
black = (0, 0, 0)
white = (255, 255, 255)
random_color = (random.randint(0, 255),
                random.randint(0, 255),
                random.randint(0, 255))

bg_music = pygame.mixer.Sound('music.mp3')
bg_music.play()

def homeScreen():
    score = '0'
    try:
        file = open('score.txt', 'r')
        score = file.read()
        file.close()
    except FileNotFoundError:
        file = open('score.txt', 'w')
        file.write(score)
        file.close()

    font = pygame.font.SysFont('Arial', 80)
    text = font.render("Welcome to Snake Game", True, red)

    font_2 = pygame.font.SysFont('Arial', 60)
    text_2 = font_2.render("Press SPACE to Start Game", True, white)

    font_3 = pygame.font.SysFont('Arial', 60)
    text_3 = font_3.render("Previous Score : {}".format(score), True, white)

    while True:
        for event in pygame.event.get():
            # print(event)
            if event.type == pygame.QUIT:
                pygame.quit()  # quit pygame
                quit()  # quit python

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    game()

        screen.fill(black)
        screen.blit(text, (100, 50))
        screen.blit(text_2, (150, 150))
        screen.blit(text_3, (200, 300))

        pygame.display.flip()

def score(counter):
    font = pygame.font.SysFont('Arial', 25)
    text = font.render("Score : {}".format(counter), True, blue)
    screen.blit(text, (400, 10))

def drawSnake(snakeList):
    for i in range(len(snakeList)):
        pygame.draw.rect(screen, red, [snakeList[i][0], snakeList[i][1],
                                       50, 50])

def gameOver(counter):
    font_2 = pygame.font.SysFont('Arial', 80)
    text_2 = font_2.render("Game Over...", True, black)

    file = open('score.txt','w')
    file.write(str(counter))
    file.close()

    while True:
        for event in pygame.event.get():
            # print(event)
            if event.type == pygame.QUIT:
                pygame.quit()  # quit pygame
                quit()
        screen.blit(text_2, (200,200))

        pygame.display.flip()

def game():
    bg_music.set_volume(0.3)

    rect_x = 0
    rect_y = 0
    rect_w = 50
    rect_h = 50
    speed = 2
    move_x = 0
    move_y = 0

    counter = 0

    snakeList = []
    snakeLength = 1

    score_sound = pygame.mixer.Sound('point.wav')

    frog_img = pygame.image.load('frog.png')
    frog_w = frog_img.get_width()
    frog_h = frog_img.get_height()
    frog_x = random.randint(0, width - frog_w)
    frog_y = random.randint(0, height - frog_h)

    clock = pygame.time.Clock()
    FPS = 100

    while True:
        for event in pygame.event.get():
            # print(event)
            if event.type == pygame.QUIT:
                pygame.quit()  # quit pygame
                quit()  # quit python

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    move_x = speed
                    move_y = 0
                elif event.key == pygame.K_LEFT:
                    move_x = -speed
                    move_y = 0
                elif event.key == pygame.K_DOWN:
                    move_y = speed
                    move_x = 0
                elif event.key == pygame.K_UP:
                    move_y = -speed
                    move_x = 0

        screen.fill(white)
        screen.blit(frog_img, (frog_x, frog_y))

        snake_rect = pygame.draw.rect(screen, red, [rect_x, rect_y, rect_w, rect_h])
        frog_rect = pygame.Rect(frog_x, frog_y, frog_w, frog_h)

        snakeHead = []
        snakeHead.append(rect_x)
        snakeHead.append(rect_y)

        snakeList.append(snakeHead)

        if len(snakeList) > snakeLength:
            del snakeList[0]

        drawSnake(snakeList)

        if snake_rect.colliderect(frog_rect):
            score_sound.play()
            frog_x = random.randint(0, width - frog_w)
            frog_y = random.randint(0, height - frog_h)
            snakeLength += 20
            FPS += 25
            counter += 1

        rect_x += move_x
        rect_y += move_y

        score(counter)

        for each in snakeList[:-1]:
            if snakeList[-1] == each:
                gameOver(counter)

        if rect_x > width:
            rect_x = -rect_w
        elif rect_x < -rect_w:
            rect_x = width

        if rect_y > height:
            rect_y = -rect_h
        elif rect_y < -rect_h:
            rect_y = height

        pygame.display.update()
        clock.tick(FPS)

homeScreen()